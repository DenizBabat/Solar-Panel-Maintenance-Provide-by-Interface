﻿namespace Bulb {
	partial class Form1 {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.ledBulb5 = new Bulb.LedBulb();
			this.ledBulb2 = new Bulb.LedBulb();
			this.ledBulb3 = new Bulb.LedBulb();
			this.ledBulb4 = new Bulb.LedBulb();
			this.ledBulb1 = new Bulb.LedBulb();
			this.ledBulb19 = new Bulb.LedBulb();
			this.ledBulb17 = new Bulb.LedBulb();
			this.ledBulb18 = new Bulb.LedBulb();
			this.ledBulb16 = new Bulb.LedBulb();
			this.ledBulb15 = new Bulb.LedBulb();
			this.ledBulb14 = new Bulb.LedBulb();
			this.ledBulb13 = new Bulb.LedBulb();
			this.ledBulb6 = new Bulb.LedBulb();
			this.ledBulb7 = new Bulb.LedBulb();
			this.flowLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// flowLayoutPanel1
			// 
			this.flowLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
			this.flowLayoutPanel1.Controls.Add(this.ledBulb5);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb2);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb3);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb4);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb1);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb19);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb17);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb18);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb16);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb15);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb14);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb13);
			this.flowLayoutPanel1.Controls.Add(this.ledBulb6);
			this.flowLayoutPanel1.Location = new System.Drawing.Point(40, 40);
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			this.flowLayoutPanel1.Size = new System.Drawing.Size(167, 113);
			this.flowLayoutPanel1.TabIndex = 7;
			// 
			// ledBulb5
			// 
			this.ledBulb5.Color = System.Drawing.Color.LawnGreen;
			this.ledBulb5.Location = new System.Drawing.Point(3, 3);
			this.ledBulb5.Name = "ledBulb5";
			this.ledBulb5.On = false;
			this.ledBulb5.Padding = new System.Windows.Forms.Padding(3);
			this.ledBulb5.Size = new System.Drawing.Size(25, 30);
			this.ledBulb5.TabIndex = 4;
			this.ledBulb5.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb2
			// 
			this.ledBulb2.Color = System.Drawing.Color.Cyan;
			this.ledBulb2.Location = new System.Drawing.Point(34, 3);
			this.ledBulb2.Name = "ledBulb2";
			this.ledBulb2.On = false;
			this.ledBulb2.Padding = new System.Windows.Forms.Padding(3);
			this.ledBulb2.Size = new System.Drawing.Size(25, 30);
			this.ledBulb2.TabIndex = 1;
			this.ledBulb2.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb3
			// 
			this.ledBulb3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(255)))), ((int)(((byte)(4)))));
			this.ledBulb3.Location = new System.Drawing.Point(65, 3);
			this.ledBulb3.Name = "ledBulb3";
			this.ledBulb3.On = false;
			this.ledBulb3.Padding = new System.Windows.Forms.Padding(3);
			this.ledBulb3.Size = new System.Drawing.Size(25, 30);
			this.ledBulb3.TabIndex = 2;
			this.ledBulb3.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb4
			// 
			this.ledBulb4.Color = System.Drawing.Color.Red;
			this.ledBulb4.Location = new System.Drawing.Point(96, 3);
			this.ledBulb4.Name = "ledBulb4";
			this.ledBulb4.On = false;
			this.ledBulb4.Padding = new System.Windows.Forms.Padding(3);
			this.ledBulb4.Size = new System.Drawing.Size(25, 30);
			this.ledBulb4.TabIndex = 3;
			this.ledBulb4.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb1
			// 
			this.ledBulb1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(255)))), ((int)(((byte)(159)))));
			this.ledBulb1.Location = new System.Drawing.Point(127, 3);
			this.ledBulb1.Name = "ledBulb1";
			this.ledBulb1.On = false;
			this.ledBulb1.Padding = new System.Windows.Forms.Padding(3);
			this.ledBulb1.Size = new System.Drawing.Size(25, 30);
			this.ledBulb1.TabIndex = 0;
			this.ledBulb1.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb19
			// 
			this.ledBulb19.Color = System.Drawing.Color.Yellow;
			this.ledBulb19.Dock = System.Windows.Forms.DockStyle.Left;
			this.ledBulb19.Location = new System.Drawing.Point(3, 39);
			this.ledBulb19.Name = "ledBulb19";
			this.ledBulb19.On = false;
			this.ledBulb19.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb19.Size = new System.Drawing.Size(34, 30);
			this.ledBulb19.TabIndex = 14;
			this.ledBulb19.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb17
			// 
			this.ledBulb17.Color = System.Drawing.Color.FromArgb(((int)(((byte)(171)))), ((int)(((byte)(255)))), ((int)(((byte)(51)))));
			this.ledBulb17.Location = new System.Drawing.Point(43, 39);
			this.ledBulb17.Name = "ledBulb17";
			this.ledBulb17.On = false;
			this.ledBulb17.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb17.Size = new System.Drawing.Size(34, 30);
			this.ledBulb17.TabIndex = 10;
			this.ledBulb17.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb18
			// 
			this.ledBulb18.Color = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(202)))), ((int)(((byte)(255)))));
			this.ledBulb18.Location = new System.Drawing.Point(83, 39);
			this.ledBulb18.Name = "ledBulb18";
			this.ledBulb18.On = false;
			this.ledBulb18.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb18.Size = new System.Drawing.Size(34, 30);
			this.ledBulb18.TabIndex = 8;
			this.ledBulb18.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb16
			// 
			this.ledBulb16.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(159)))), ((int)(((byte)(116)))));
			this.ledBulb16.Location = new System.Drawing.Point(123, 39);
			this.ledBulb16.Name = "ledBulb16";
			this.ledBulb16.On = false;
			this.ledBulb16.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb16.Size = new System.Drawing.Size(34, 30);
			this.ledBulb16.TabIndex = 7;
			this.ledBulb16.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb15
			// 
			this.ledBulb15.Color = System.Drawing.Color.FromArgb(((int)(((byte)(156)))), ((int)(((byte)(68)))), ((int)(((byte)(255)))));
			this.ledBulb15.Location = new System.Drawing.Point(3, 75);
			this.ledBulb15.Name = "ledBulb15";
			this.ledBulb15.On = false;
			this.ledBulb15.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb15.Size = new System.Drawing.Size(34, 30);
			this.ledBulb15.TabIndex = 11;
			this.ledBulb15.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb14
			// 
			this.ledBulb14.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(221)))));
			this.ledBulb14.Location = new System.Drawing.Point(43, 75);
			this.ledBulb14.Name = "ledBulb14";
			this.ledBulb14.On = false;
			this.ledBulb14.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb14.Size = new System.Drawing.Size(34, 30);
			this.ledBulb14.TabIndex = 12;
			this.ledBulb14.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb13
			// 
			this.ledBulb13.Color = System.Drawing.Color.FromArgb(((int)(((byte)(111)))), ((int)(((byte)(250)))), ((int)(((byte)(255)))));
			this.ledBulb13.Location = new System.Drawing.Point(83, 75);
			this.ledBulb13.Name = "ledBulb13";
			this.ledBulb13.On = false;
			this.ledBulb13.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb13.Size = new System.Drawing.Size(34, 30);
			this.ledBulb13.TabIndex = 13;
			this.ledBulb13.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb6
			// 
			this.ledBulb6.Color = System.Drawing.Color.LightPink;
			this.ledBulb6.Dock = System.Windows.Forms.DockStyle.Fill;
			this.ledBulb6.Location = new System.Drawing.Point(123, 75);
			this.ledBulb6.Name = "ledBulb6";
			this.ledBulb6.On = false;
			this.ledBulb6.Padding = new System.Windows.Forms.Padding(5, 3, 5, 3);
			this.ledBulb6.Size = new System.Drawing.Size(34, 30);
			this.ledBulb6.TabIndex = 15;
			this.ledBulb6.Click += new System.EventHandler(this.ledBulb_Click);
			// 
			// ledBulb7
			// 
			this.ledBulb7.BackColor = System.Drawing.Color.Transparent;
			this.ledBulb7.Color = System.Drawing.Color.GreenYellow;
			this.ledBulb7.Dock = System.Windows.Forms.DockStyle.Right;
			this.ledBulb7.Location = new System.Drawing.Point(226, 30);
			this.ledBulb7.Name = "ledBulb7";
			this.ledBulb7.On = false;
			this.ledBulb7.Padding = new System.Windows.Forms.Padding(10);
			this.ledBulb7.Size = new System.Drawing.Size(188, 164);
			this.ledBulb7.TabIndex = 16;
			this.ledBulb7.Click += new System.EventHandler(this.ledBulb7_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
			this.BackgroundImage = global::Bulb.Properties.Resources.woodback1;
			this.ClientSize = new System.Drawing.Size(424, 224);
			this.Controls.Add(this.flowLayoutPanel1);
			this.Controls.Add(this.ledBulb7);
			this.DoubleBuffered = true;
			this.Name = "Form1";
			this.Padding = new System.Windows.Forms.Padding(30, 30, 10, 30);
			this.ShowIcon = false;
			this.Text = "Click Bulb to Turn On";
			this.flowLayoutPanel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private LedBulb ledBulb1;
		private LedBulb ledBulb2;
		private LedBulb ledBulb3;
		private LedBulb ledBulb4;
		private LedBulb ledBulb5;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private LedBulb ledBulb19;
		private LedBulb ledBulb17;
		private LedBulb ledBulb18;
		private LedBulb ledBulb16;
		private LedBulb ledBulb15;
		private LedBulb ledBulb14;
		private LedBulb ledBulb13;
		private LedBulb ledBulb6;
		private LedBulb ledBulb7;

	}
}

